<?php
declare(strict_types=1);

namespace App\Service\Plugins\Demo;

use App\Model\User;
use App\Service\BaseService;
use Hyperf\Di\Annotation\Inject;

/**
 * Class UserService
 * @package App\Service\Plugins\Demo
 */
class UserService extends BaseService
{
    /**
     * @Inject()
     * @var User
     */
    public $table;
}