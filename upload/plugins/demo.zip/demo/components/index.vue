<template>
    <div>

    </div>
</template>

<script>
    export default {
        data() {
            return {
                name: 'test'
            }
        }
    }
</script>

<style scoped>
</style>  