<?php
declare(strict_types=1);

namespace App\Controller\Admin\Plugins\Demo;

use App\Controller\Admin\Plugins\BaseController;
use App\Service\Plugins\Demo\UserService;
use Hyperf\Di\Annotation\Inject;
use Hyperf\HttpServer\Annotation\Controller;
use Hyperf\HttpServer\Annotation\RequestMapping;
use Hyperf\HttpServer\Contract\RequestInterface;

/**
 * @Controller()
 * Class IndexController
 * @package App\Controller\Admin\Plugins\Demo
 */
class IndexController extends BaseController
{
    /**
     * @Inject()
     * @var UserService
     */
    public $service;
    /**
     * @RequestMapping(path="index", methods="get, post")
     * @return array
     */
    public function index(RequestInterface $request)
    {
        $user = $this->request->input('user', 'MQCMS-plugin-demo');
        $method = $this->request->getMethod();

        return [
            'method' => $method,
            'message' => "Hello {$user}."
        ];
    }
}
