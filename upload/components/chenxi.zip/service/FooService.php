<?php


class FooService
{

}